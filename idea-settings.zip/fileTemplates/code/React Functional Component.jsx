const $!NAME = (#if($HAS_PROPS)props#end) => (
  $COMPONENT_BODY
)
